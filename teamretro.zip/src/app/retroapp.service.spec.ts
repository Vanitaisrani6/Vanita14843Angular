import { TestBed } from '@angular/core/testing';

import { RetroappService } from './retroapp.service';

describe('RetroappService', () => {
  let service: RetroappService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RetroappService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
