export interface Sectionname1 {
    SectionId:number
    Section_Description1:string
}
