export interface Sectionname3 {
    SectionId:number
    Section_Description3:string
}
