export interface Description {
    RetroId: number
    SectionId:number
    RetroDescription:string
}
