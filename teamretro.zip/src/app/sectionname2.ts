export interface Sectionname2 {
    SectionId:number
    Section_Description2:string
}
