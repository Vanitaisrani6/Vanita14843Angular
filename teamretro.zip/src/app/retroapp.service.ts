import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Sectionname1 } from './sectionname1';
import { Description } from './description';

@Injectable({
  providedIn: 'root'
})
export class RetroappService {

  serverURL:string
  constructor(private httpsvc:HttpClient) { 
    this.serverURL="http://localhost:7077/"

  }
  

    addRetroSectionBySectionId(Sectionname1:Sectionname1):Observable<Sectionname1>{
    
      // var sectiondata="SectionId="+SectionId+ "&Section_Description"+Section_Description
      var sectiondata="";
     console.log(sectiondata)


      var httpOptions = { // add the header for request body format type
               headers: new HttpHeaders(
             {"Content-Type":"application/x-www-form-urlencoded"})
          }
         return this.httpsvc.post<Sectionname1>(this.serverURL+"retro/newsection",sectiondata,httpOptions)
   }

  //  getProjectsByEmpno(empno:number):Observable<Project[]>{
  //    return this.httpsvc.get<Project[]>(this.serverURL+"emp/list/"+empno)

    
  //  }

registernewRetro(description:Description):Observable<Description>{
     //format= key=value&key=value
  // var retrodata = "RetroDescription="+RetroDescription
  var retrodata=""
   
    console.log(retrodata)

    var httpOptions = { // add the header for request body format type
        headers: new HttpHeaders(
           {"Content-Type":"application/x-www-form-urlencoded"})
   }

    return this.httpsvc.post<Description>(this.serverURL+"/retro/newretro",retrodata,httpOptions)

 }

// deleteProjectByProjectId(empno:number,projectid:number):Observable<String>{
//   return this.httpsvc.get<String>(
//       this.serverURL+"emp/"+empno+"/project/delete/"+projectid)
// }

}
