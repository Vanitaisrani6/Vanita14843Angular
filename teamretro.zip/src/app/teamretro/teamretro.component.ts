import { Component, OnInit } from '@angular/core';
import { Description } from '../description';
import { RetroappService } from '../retroapp.service';
import { Sectionname1 } from '../sectionname1';
import { Sectionname2 } from '../sectionname2';
import { Sectionname3 } from '../sectionname3';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-teamretro',
  templateUrl: './teamretro.component.html',
  styleUrls: ['./teamretro.component.css']
})
export class TeamretroComponent implements OnInit {
  retroname:string
  Section_Description2:string
  Section_Description1:string
  Section_Description3:string
  isPart1_StickyVisible:boolean

  isViewMode:Boolean
  sectionname1:Sectionname1[]
  sectionname2:Sectionname2[]
  sectionname3:Sectionname3[]
  // textarea:string

  
  description:Description[]
partsvc: any;

  constructor() {



  this.retroname="Team Retrospective"
  this.isViewMode=true
  this.isPart1_StickyVisible=true
  this.Section_Description1="plan"
  this.Section_Description2="approach"
  this.Section_Description3="success"

this.sectionname1=[
  {
    SectionId:101,
  Section_Description1:"plan"
}
]
this.sectionname2=[
  {SectionId:102,
  Section_Description2:"approach"}
]
this.sectionname3=[
  {SectionId:103,
  Section_Description3:"success"}
]

  // this.textarea=""

  this.description=[
    {RetroId:1,SectionId:101,RetroDescription:"vanita israni working on NHS project"},
    {RetroId:2,SectionId:102,RetroDescription:"vanita israni will use angular stack"},
    {RetroId:3,SectionId:103,RetroDescription:"vanita israni has sucessfully created DB for the same."},
  ]

   }

  //  getallretro():Observable<Description[]>{
  //   return this.httpsvc.get<Description[]>(this.serverURL+"emp/list/")
  // }

   toggleModeforEmpform():void{
    this.isViewMode=!this.isViewMode
    
    }

    deleteStickyById(index:number){
      this.sectionname3.splice(index,1)
    }

    // registernewRetro(description:Description):void{

    //   this.teamsvc.registernewRetro(description).subscribe(
    //     response=>{
    //       console.log(response)
    //       // fetch projects from server
    //       this.teamsvc.getProjectsByEmpno(this.empno).subscribe(
    //         response=>{
    //           this.projects = response
    //           sessionStorage.setItem("projects",
    //               JSON.stringify(this.projects))      
    //           this.errorInProjectForm=""
    //           this.isprojectFormVisible=false
    //         },
    //         error=>{console.log(error)}
    //       )
    //     },
    //     error=>{console.log(error)}
    //   )
    
    //   }



    // }


    textAreasList1:any = [];
    textAreasList2:any = [];
    textAreasList3:any = [];
    addTextarea1(){        
        this.textAreasList1.push('text_area'+ (this.textAreasList1.length + 1));
        // console.log('it does nothing',this.textarea);
    }
    addTextarea2(){        
      this.textAreasList2.push('text_area'+ (this.textAreasList2.length + 1));
      // console.log('it does nothing',this.textarea);
  }
    addTextarea3(){        
      this.textAreasList3.push('text_area'+ (this.textAreasList3.length + 1));
      // console.log('it does nothing',this.textarea);
  }

    removeTextArea1(index: any){
        this.textAreasList1.splice(index, 1);
    }
    removeTextArea2(index: any){
      this.textAreasList2.splice(index, 1);
  }
   removeTextArea3(index: number)
   {
       this.textAreasList3.splice(index, 1);
    }

  ngOnInit(): void {
  }

}
