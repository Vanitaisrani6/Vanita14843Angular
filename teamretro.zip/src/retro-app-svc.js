const express = require('express')
var cors = require('cors')

const retroapp = express()
const port = 7077

retroapp.use(express.urlencoded({extended:false}))
retroapp.use(express.json())
// database connection settings
var mysqldb = require('mysql')
const { ValueTransformer } = require('@angular/compiler/src/util')
const e = require('cors')
const { json } = require('body-parser')


var connection = mysqldb.createConnection({
    host: 'localhost',
    user: 'root',
    port: 3306,
    password: 'root',
    database: 'retro'
})

connection.connect()
retroapp.use(cors());

    

//app.METHOD(PATH, HANDLER)
retroapp.get('/', (req, res) => {
    console.log("Team Retro Service Called")
  res.send('Retrospective Information Application')
})

retroapp.get('/retro/retrodescription/:sectionno',(req,res)=>{
     var selectSQL = 'Select SectionId,Section_Description from section_details'

     connection.query(selectSQL, function (err, rows, fields) {
        if (err) throw err

       console.log('Retros Fetched ', rows.length)
         res.send(rows)
    })
  //connection.end()

})

retroapp.post('/retro/newsection',(req,res)=>{

  var SectionId = req.body.SectionId
  var Section_Description = req.body.Section_Description
 
  var insertSQL = "insert into section_details (SectionId,Section_Description) values(?,?)"


  connection.query(insertSQL,[SectionId,Section_Description],
    function (err, rows, fields) {
      if (err) throw err

        console.log(SectionId+" Registered for "+Section_Description)

        res.send({"SectionId":SectionId,"Section_Description":Section_Description})
    })
})

retroapp.post('/retro/newretro',(req,res)=>{

  // var RetroId = req.body.RetroId
  // var SectionId = req.body.SectionId
  var RetroDescription=req.body.RetroDescription
 
  var insertSQL = "insert into retrodetails (RetroDescription) values(?)"


  connection.query(insertSQL,[RetroDescription],
    function (err, rows, fields) {
      if (err) throw err

        // console.log(RetroId+" Registered for "+SectionId)

        res.send({"RetroDescription":RetroDescription})
    })
})



retroapp.listen(port, () => {
  console.log(`Retro app started and listening at http://localhost:${port}`)
})