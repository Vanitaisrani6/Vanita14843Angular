import { Component, OnInit,EventEmitter,Output } from '@angular/core';
import {Recipe} from '../recipe.model';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
  @Output() recipewasselected=new EventEmitter<Recipe>();
recipes: Recipe[]=[
  new Recipe('WHITE SAUCE PASTA','This is white sauce cream based Penny Pasta cooked with wheat flour..!! Yummy should try....',
  'https://www.indianhealthyrecipes.com/wp-content/uploads/2019/05/masala-pasta.jpg'),
  new Recipe('NOODLES','This noodles served hot with mancurian white soya and red chill sauce..!! Yummy should try....',
  'https://www.indianhealthyrecipes.com/wp-content/uploads/2019/05/masala-pasta.jpg'),
];

  constructor() { }

  ngOnInit(): void {
  }
  onRecipeSelected(recipe: Recipe)
  {
this.recipewasselected.emit(recipe);
  }

}
