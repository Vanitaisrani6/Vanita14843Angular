import { Component, OnInit } from '@angular/core';
import { Project } from '../project';
import { ProjectappService } from '../projectapp.service';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {

  empno:number
  ename:string
  designation:string
  dateofJoining:Date
  biodetails:string
  isViewMode:Boolean
  isprojectFormVisible:Boolean
  errorInProjectForm:string
  houseColor:string

  projects: Project[]

  constructor(private prjsvc:ProjectappService) { 
    this.empno=14843,
    this.ename="Vanita U. Israni"
    this.designation="Traniee Software Engineer"
    this.dateofJoining=new Date("01/28/2021")
    this.houseColor="lime"
    this.biodetails="An dedicated hardworking engineer and passionate about coding"

    this.projects=[
      {projectid:1001,name:"Admin",location:"Pune"},
      {projectid:1002,name:"NHS",location:"Mumbai"},
      {projectid:1003,name:"Angular",location:"Banglore"}
    ]

    this.isViewMode=true
    this.isprojectFormVisible=false
    this.errorInProjectForm=""

  }

toggleModeforEmpform():void{
this.isViewMode=!this.isViewMode

}
deleteProjectByIndex(index:number):void{
this.projects.splice(index,1)

}

registerNewProject(newProject:Project):void{

  if(newProject.projectid<1000 || newProject.projectid>9999)
  {
this.errorInProjectForm="Project Id must be 4 digits"

  }
  else if(newProject.name.length<5 || newProject.name.length>16)
  {
this.errorInProjectForm="project length must be between 5 to 16 characters"

  }
  else{
  //   this.projects.push(newProject)
  //  sessionStorage.setItem("project",JSON.stringify(this.projects))
  //   this.errorInProjectForm=""
  //   this.isprojectFormVisible=false



  this.prjsvc.registerEmployeeProject(this.empno,newProject).subscribe(
    response=>{
      console.log(response)
      // fetch projects from server
      this.prjsvc.getProjectsByEmpno(this.empno).subscribe(
        response=>{
          this.projects = response
          sessionStorage.setItem("projects",
              JSON.stringify(this.projects))      
          this.errorInProjectForm=""
          this.isprojectFormVisible=false
        },
        error=>{console.log(error)}
      )
    },
    error=>{console.log(error)}
  )

  }

}


ngOnInit(): void {
  var empnoval = Number.parseInt(localStorage.getItem("empno")+"")
 
  if(!isNaN(+empnoval)){
    this.empno = +empnoval
  }
  localStorage.setItem("empno",this.empno.toString())

  this.prjsvc.getProjectsByEmpno(this.empno).subscribe(
    response=>{
      this.projects = response
    },
    error=>{console.log(error)}
  )

  sessionStorage.setItem("projects",JSON.stringify(this.projects))      
}

deleteProjectById(projectid:number):void{
  this.prjsvc.deleteProjectByProjectId(this.empno,projectid).subscribe(
      response=>{
          console.log(response)
          this.prjsvc.getProjectsByEmpno(this.empno).subscribe(
            response=>{
              this.projects = response    
            },
            error=>{console.log(error)}
            )
      },
      error=>{console.log(error)}
  )
}


showProjectForm():void{
  this.isprojectFormVisible=true
}


}
