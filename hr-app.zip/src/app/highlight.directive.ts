import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[highlight]'
})
export class HighlightDirective {

@Input("highlight")
color:string

  constructor(private currentElemnt:ElementRef) { 

    this.color="yellow"
  }

  private changeBackColor(color:string)
  {
    this.currentElemnt.nativeElement.style.backgroundColor=color
  }

@HostListener("mouseenter")
  applycolorOnMouseOver()
  {
    this.changeBackColor(this.color)
  }


@HostListener("mouseleave")
  removeColorOnMouseOut()
  {
    this.changeBackColor("")
  }

}
