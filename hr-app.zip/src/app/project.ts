export interface Project {
    projectid: number
    name:string
    location:string
}
