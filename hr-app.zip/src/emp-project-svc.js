const express = require('express')
var cors = require('cors')

const empapp = express()
const port = 7077
//body parcel 

// var bodyparser=require('body-parser')
empapp.use(express.urlencoded({extended:false}))
empapp.use(express.json())

var mysqldb = require('mysql')
const { ValueTransformer } = require('@angular/compiler/src/util')
const e = require('cors')
const { json } = require('body-parser')


var connection = mysqldb.createConnection({
  host: 'localhost',
  user: 'root',
  port: 3306,
  password: 'root',
  database: 'tester'
})
connection.connect()

empapp.use(cors());

empapp.get('/', (req, res) => {
  res.send('Employee Infomation Application')
})

empapp.post('/emp/register',(req,res)=>{
  var empno = req.body.empno
  var name = req.body.name
  var projectid = req.body.projectid
  var location = req.body.location

  var insertSQL = "insert into employee_projects (empno,projectid,name,location) values(?,?,?,?)"


  connection.query(insertSQL,[empno,projectid,name,location],
    function (err, rows, fields) {
      if (err) throw err

        console.log(projectid+" Registered for "+empno)

        res.send({"empno":empno,"name":name,"projectid":projectid,"location":location})
    })
})

empapp.get("/emp/:empno/project/delete/:projectid",(req,res)=>{
  var empno = req.params.empno
  var projectid= req.params.projectid

  var deleteSQL = "delete from employee_projects where empno=? and projectid=?"

  connection.query(deleteSQL,[empno,projectid],
    function (err, rows, fields) {
      if (err) throw err

      var message =projectid+" Deleted for Employee "+empno
      console.log(message)

      res.send({"message":message})
    })

})


 empapp.listen(port, () => {
   console.log(`Employee app started and listening at http://localhost:${port}`)
 })

empapp.get('/emp/list/:empno',(req, res)=>

{
  var empno=req.params.empno
    var selectsql= 'SELECT empno,projectid,name,location from EMPLOYEE_PROJECTS where empno=?'
    

connection.query(selectsql,[empno], function (err, rows, fields) {
  if (err) throw err

  console.log('Employees Fetched: ', rows.length)
  res.send(rows)
})

// connection.end()
})
